package com.woniu.dao;

public interface OrderDao {
	
}
