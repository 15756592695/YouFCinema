package com.woniu.dao;

public interface SeatRecordsDao {

}
